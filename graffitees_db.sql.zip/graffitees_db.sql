-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 11, 2011 at 04:38 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `graffitees_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `Cust_ID` int(11) NOT NULL AUTO_INCREMENT,
  `UL_ID` int(11) NOT NULL,
  `Cust_DateIn` datetime NOT NULL,
  `Cust_Firstname` varchar(30) NOT NULL,
  `Cust_Lastname` varchar(30) DEFAULT NULL,
  `Cust_Email` varchar(50) NOT NULL,
  `Cust_LoginID` varchar(20) NOT NULL,
  `Cust_Passwd` varchar(64) NOT NULL,
  `Cust_CCName` varchar(30) DEFAULT NULL,
  `Cust_CCNum` varchar(64) DEFAULT NULL,
  `Cust_CCExDate` date DEFAULT NULL,
  `Cust_BilAddr1` varchar(50) DEFAULT NULL,
  `Cust_BilAddr2` varchar(50) DEFAULT NULL,
  `Cust_BilCity` varchar(30) DEFAULT NULL,
  `Cust_BilState` tinyint(2) DEFAULT NULL,
  `Cust_BilZip` varchar(5) DEFAULT NULL,
  `Cust_BilCntry` varchar(2) DEFAULT NULL,
  `Cust_BilPhone` varchar(15) DEFAULT NULL,
  `Ship_ID` int(11) NOT NULL,
  `Cust_ShpAddr1` varchar(50) NOT NULL,
  `Cust_ShpAddr2` varchar(50) DEFAULT NULL,
  `Cust_ShpCity` varchar(30) NOT NULL,
  `Cust_ShpState` tinyint(2) NOT NULL,
  `Cust_ShpZip` varchar(5) NOT NULL,
  `Cust_ShpCntry` varchar(2) NOT NULL,
  `Cust_ShpPhone` varchar(15) NOT NULL,
  `Cust_MbrType` tinyint(1) NOT NULL,
  PRIMARY KEY (`Cust_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `Ord_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Ord_Date` datetime NOT NULL,
  `Cust_ID` int(11) NOT NULL,
  `Pmt_ID` int(11) NOT NULL,
  `Ord_CCName` varchar(30) DEFAULT NULL,
  `Ord_CCNum` varchar(64) DEFAULT NULL,
  `Ord_CCExDate` date DEFAULT NULL,
  `Ship_ID` int(11) NOT NULL,
  `Ord_ShpAddr1` varchar(50) NOT NULL,
  `Ord_ShpAddr2` varchar(50) DEFAULT NULL,
  `Ord_ShpCity` varchar(30) NOT NULL,
  `Ord_ShpState` tinyint(2) NOT NULL,
  `Ord_ShpZip` varchar(5) NOT NULL,
  `Ord_ShpCntry` varchar(2) NOT NULL,
  `Ord_ShpDate` date NOT NULL,
  `Ord_ShpCost` float DEFAULT '0',
  `Ord_ProdCost` float NOT NULL,
  `Ord_TaxCost` float DEFAULT '0',
  `Prom_ID` int(11) NOT NULL,
  `Ord_TotCost` float NOT NULL,
  `Ord_Status` varchar(10) DEFAULT 'Pending',
  PRIMARY KEY (`Ord_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `order`
--


-- --------------------------------------------------------

--
-- Table structure for table `orderline`
--

CREATE TABLE IF NOT EXISTS `orderline` (
  `Orl_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Ord_ID` int(11) NOT NULL,
  `Prod_ID` int(11) NOT NULL,
  `Orl_Qty` int(5) NOT NULL,
  `Orl_Price` float NOT NULL,
  `Orl_Tax` float DEFAULT NULL,
  `Ship_ID` int(11) NOT NULL,
  `Orl_ShipDate` date NOT NULL,
  PRIMARY KEY (`Orl_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `orderline`
--


-- --------------------------------------------------------

--
-- Table structure for table `pmttype`
--

CREATE TABLE IF NOT EXISTS `pmttype` (
  `Pmt_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Pmt_Name` varchar(20) NOT NULL,
  `Pmt_Mchnt_Id` varchar(20) DEFAULT NULL,
  `Pmt_Notes` text,
  PRIMARY KEY (`Pmt_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pmttype`
--


-- --------------------------------------------------------

--
-- Table structure for table `prodtype`
--

CREATE TABLE IF NOT EXISTS `prodtype` (
  `PType_ID` int(11) NOT NULL AUTO_INCREMENT,
  `PType_Name` varchar(20) NOT NULL,
  `PType_Parent` varchar(20) NOT NULL,
  PRIMARY KEY (`PType_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `prodtype`
--


-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `Prod_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Prod_Name` varchar(30) NOT NULL,
  `Prod_Descr` varchar(100) DEFAULT NULL,
  `Prod_Option` text NOT NULL,
  `Prod_Image_Name` varchar(30) NOT NULL,
  `Prod_Thumb_Name` varchar(30) NOT NULL,
  `PType_ID` int(11) NOT NULL,
  `Prod_QOH` int(5) NOT NULL,
  `Prod_QOrder` int(5) NOT NULL,
  `Prod_Reord_Level` int(5) DEFAULT NULL,
  `Prod_Reord_Qty` int(5) DEFAULT NULL,
  `Prod_Price` float NOT NULL,
  `Prod_Price_D1` float DEFAULT NULL,
  `Prod_Price_D2` float DEFAULT NULL,
  `Prod_Promo` varchar(3) NOT NULL DEFAULT 'No',
  `Prod_Weight` tinyint(2) NOT NULL,
  `Prod_Active` varchar(3) NOT NULL,
  PRIMARY KEY (`Prod_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Prod_ID`, `Prod_Name`, `Prod_Descr`, `Prod_Option`, `Prod_Image_Name`, `Prod_Thumb_Name`, `PType_ID`, `Prod_QOH`, `Prod_QOrder`, `Prod_Reord_Level`, `Prod_Reord_Qty`, `Prod_Price`, `Prod_Price_D1`, `Prod_Price_D2`, `Prod_Promo`, `Prod_Weight`, `Prod_Active`) VALUES
(1, 'Limited Edition - DINO FRENZY', 'Limited Edition - DINO FRENZY Details', 'gender-m|size-s,m,l,xl,2xl', '2pxq_9lu-640x480-b.png', '2pxq_9lu-133x234.png', 1, 20, 5, 5, 5, 22, 20, 18, 'No', 1, 'Yes'),
(2, 'Meteor Shower', 'Meteor Shower Details', 'gender-m|size-s,m,l,xl,2xl', '2pe0_cod-133x234.png', '2pe0_cod-133x234.png', 1, 20, 5, 5, 5, 15, 13, 10, 'No', 1, 'Yes'),
(3, 'Shattered', 'Shattered Details', 'gender-m|size-s,m,l,xl,2xl', '2p3w_05j-133x234.png', '2p3w_05j-133x234.png', 1, 20, 5, 5, 5, 12, 10, 8, 'No', 1, 'Yes'),
(4, 'Giant Octopus', 'Giant Octopus Details', 'gender-m|size-s,m,l,xl,2xl', '2p3l_v1a-133x234.png', '2p3l_v1a-133x234.png', 1, 20, 5, 5, 5, 20, 18, 16, 'No', 1, 'Yes'),
(5, 'I <3 My City', 'I <3 My City Details', 'gender-m|size-s,m,l,xl,2xl', '2opi_xfy-133x234.png', '2opi_xfy-133x234.png', 1, 20, 5, 5, 5, 20, 18, 16, 'No', 1, 'Yes'),
(6, 'Limited Edition - DINO FRENZY', 'Limited Edition - DINO FRENZY Details', 'gender-f|size-s,m,l,xl,2xl', '2pxs_qsn-640x480-b.png', '2pxs_qsn-133x234.png', 1, 20, 5, 5, 5, 22, 20, 18, 'No', 1, 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `promotion`
--

CREATE TABLE IF NOT EXISTS `promotion` (
  `Promo_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Promo_Name` varchar(30) NOT NULL,
  `Promo_Date` date NOT NULL,
  `Promo_BegDate` date NOT NULL,
  `Promo_EndDate` int(11) NOT NULL,
  `PType_Id` int(11) DEFAULT NULL,
  `Prod_ID` int(11) DEFAULT NULL,
  `Promo_MinQty` int(5) DEFAULT NULL,
  `Promo_MaxQty` int(5) DEFAULT NULL,
  `Promo_MinPur` float DEFAULT NULL,
  `Promo_PctDisc` float DEFAULT NULL,
  `Promo_MYR` float DEFAULT NULL,
  `Promo_Ceiling` float DEFAULT NULL,
  PRIMARY KEY (`Promo_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `promotion`
--


-- --------------------------------------------------------

--
-- Table structure for table `shiptype`
--

CREATE TABLE IF NOT EXISTS `shiptype` (
  `Ship_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Ship_Name` varchar(50) NOT NULL,
  `Ship_Cost` float NOT NULL,
  `Ship_Notes` text,
  PRIMARY KEY (`Ship_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `shiptype`
--


-- --------------------------------------------------------

--
-- Table structure for table `shopcart`
--

CREATE TABLE IF NOT EXISTS `shopcart` (
  `Cart_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Cart_Prod_ID` int(11) NOT NULL,
  `Cart_Qty` int(5) NOT NULL DEFAULT '1',
  PRIMARY KEY (`Cart_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `shopcart`
--


-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `State_ID` tinyint(2) NOT NULL AUTO_INCREMENT,
  `State_Name` varchar(30) NOT NULL,
  PRIMARY KEY (`State_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `state`
--


-- --------------------------------------------------------

--
-- Table structure for table `userlogin`
--

CREATE TABLE IF NOT EXISTS `userlogin` (
  `UL_ID` int(11) NOT NULL AUTO_INCREMENT,
  `UL_UserName` varchar(20) NOT NULL,
  `UL_UserPass` varchar(64) NOT NULL,
  `UL_UserLevel` varchar(40) NOT NULL,
  `UL_SessionID` varchar(20) NOT NULL,
  `UL_LoginDate` datetime NOT NULL,
  PRIMARY KEY (`UL_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `userlogin`
--

INSERT INTO `userlogin` (`UL_ID`, `UL_UserName`, `UL_UserPass`, `UL_UserLevel`, `UL_SessionID`, `UL_LoginDate`) VALUES
(1, 'admin', '827ccb0eea8a706c4c34a16891f84e7b', 'ADMINISTRATOR', '', '2011-12-10 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
